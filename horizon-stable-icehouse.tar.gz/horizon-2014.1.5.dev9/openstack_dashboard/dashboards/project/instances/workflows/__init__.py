# Importing non-modules that are not used explicitly

from create_instance import LaunchInstance  # noqa
from resize_instance import ResizeInstance  # noqa
from update_instance import UpdateInstance  # noqa
