JSEncrypt
==============

This directory contains RSA Javascript encryption library.

Source code
==============

The library source code can be found here:
 - https://github.com/travist/jsencrypt/

Version
==============

The library version included here is based on github commit
cc1109283b5f9944f77410e80e6789dc298827e1

Files
==============

 - README.md
 - LICENCE.txt
 - jsencrypt.js